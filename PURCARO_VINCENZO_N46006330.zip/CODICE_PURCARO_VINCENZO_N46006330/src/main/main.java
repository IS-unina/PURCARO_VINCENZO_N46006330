package main;

import boundary.*;
import control.*;
import entity.*;
import database.*;


public class main {

	public static void main(String[] args) {
		
	DBManager connessione = DBManager.getInstance();
	Control PizzaaCasa = Control.getInstance(connessione);

	Ristorante ristorante1 = new Ristorante ("BellaNapoli","Via Tevere","6A","80011","Acerra","tony@gmail.com","3338904567");
	Ristoratore ristoratore1 = new Ristoratore ("Antonio","Messina",ristorante1.getNome(),ristorante1.getVia(),ristorante1.getNumero(),ristorante1.getCAP(),ristorante1.getCittà(),ristorante1.getRecapitoTelefonico(),ristorante1.getIndirizzoEmail());
	
	
	BoundaryRistoratore interfaccia1 = new BoundaryRistoratore (ristoratore1);
	
	//PizzaaCasa.modificaPizza(interfaccia1);
			
	Cliente cliente1 = new Cliente ("Marco","Rossi","3345091256","dhgdhy@gmail.com");
	
	BoundaryCliente interfaccia2 = new BoundaryCliente ();
	
	PizzaaCasa.effettuaOrdine(interfaccia2);
	
	
	


		
		
		
		
		

	}

}
