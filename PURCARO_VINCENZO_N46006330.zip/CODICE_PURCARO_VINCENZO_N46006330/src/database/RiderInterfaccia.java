package database;

public interface RiderInterfaccia {

}
