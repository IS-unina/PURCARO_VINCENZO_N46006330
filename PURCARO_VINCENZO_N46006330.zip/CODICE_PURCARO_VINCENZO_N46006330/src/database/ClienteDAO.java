package database;

public class ClienteDAO implements ClienteInterfaccia {

}
