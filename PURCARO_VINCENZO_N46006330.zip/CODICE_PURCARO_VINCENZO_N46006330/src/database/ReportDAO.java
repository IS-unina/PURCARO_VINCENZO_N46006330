package database;

public class ReportDAO implements ReportInterfaccia {

}
