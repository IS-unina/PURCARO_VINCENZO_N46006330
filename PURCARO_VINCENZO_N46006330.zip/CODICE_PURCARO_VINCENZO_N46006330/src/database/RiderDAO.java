package database;

public class RiderDAO implements RiderInterfaccia {

}
