package database;

import java.sql.*;

public class RistoratoreDAO implements RistoratoreInterfaccia {
	
	public void readRistoratore () {
		
	}
	
	public void createRistoratore () {
		
	}
	
	public void updateRistoratore () {
		
	}
	
	public void deleteRistoratore () {
		
	}

}
