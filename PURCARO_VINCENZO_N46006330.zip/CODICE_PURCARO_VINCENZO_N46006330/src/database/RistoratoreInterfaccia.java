package database;

import entity.*;

public interface RistoratoreInterfaccia {
	
	void readRistoratore ();
	void createRistoratore ();
	void updateRistoratore ();
	void deleteRistoratore ();

}
