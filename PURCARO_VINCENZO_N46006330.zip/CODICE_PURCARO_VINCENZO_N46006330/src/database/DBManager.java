package database;

import java.sql.*;

public class DBManager {
	
private static DBManager instance = null;
private Connection connection;

private DBManager() {
try {

String url = "jdbc:mysql://localhost:3306/Pizza@casa";
String user = "Dbmanager"; 
String password = "yhhZK75ngJ47t6GE"; 
            
connection = DriverManager.getConnection(url, user, password); } 

catch (SQLException e) {e.printStackTrace();}

}

    public static DBManager getInstance() {
        if (instance == null) {
            instance = new DBManager(); 
        }
        return instance;}

    public Connection getConnection() {return connection;}
    
    public void closeConnection() {
        if (connection != null) {
            try {
                connection.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
        }
    
    
    
}

