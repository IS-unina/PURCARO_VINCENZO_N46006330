package database;

import java.sql.*;
import entity.*;

public class PizzaDAO implements PizzaInterfaccia {

	private DBManager dbManager;
	
	public PizzaDAO(DBManager dbManager) {
        this.dbManager = dbManager;
    }
	
	public void createPizza(Pizza pizza) {
		
	        String query = "INSERT INTO Pizza (nome, descrizione, prezzo, via_ristorante,numero_ristorante, città_ristorante) VALUES (?, ?, ?, ?, ?,?)";
	        
	        try (PreparedStatement statement = dbManager.getConnection().prepareStatement(query)) {
	            
	            statement.setString(1, pizza.getNome());
	            statement.setString(2, pizza.getDescrizione());
	            statement.setDouble(3, pizza.getPrezzo());
	            statement.setString(4, pizza.getRistorante().getVia());
	            statement.setString(5, pizza.getRistorante().getNumero());
	            statement.setString(6, pizza.getRistorante().getCittà());

	            statement.executeUpdate();
	            
	        } catch (SQLException e) {
	            e.printStackTrace();
	            throw new RuntimeException("Errore durante l'inserimento della pizza", e);
	        }
	        
	             	
	}
	
	
	public boolean readPizza (Pizza pizza ) {
		
	boolean found = false;
		
	String query = "SELECT nome, descrizione, prezzo, via_ristorante, numero_ristorante,città_ristorante FROM Pizza WHERE nome = ? AND via_ristorante = ? AND numero_ristorante = ? AND città_ristorante = ?";
	try (PreparedStatement statement = dbManager.getConnection().prepareStatement(query)) {
        
    statement.setString(1, pizza.getNome());
    statement.setString(2, pizza.getRistorante().getVia());
    statement.setString(3, pizza.getRistorante().getNumero());
    statement.setString(4, pizza.getRistorante().getCittà());
    
    
    try (ResultSet resultSet = statement.executeQuery()) {
        if (resultSet.next()) {
            
            String descrizione = resultSet.getString("descrizione");
            float prezzo = resultSet.getFloat("prezzo");

            pizza.setDescrizione(descrizione);
            pizza.setPrezzo(prezzo);
            
            found = true;} 
        
    	}
		} 
	
	catch (SQLException e) {
    e.printStackTrace();
    throw new RuntimeException("Errore durante la ricerca della pizza", e);
	}
	
	return found;
	}
	
	
	
	public boolean updatePizza(Pizza pizza) {
        
        String query = "UPDATE Pizza SET descrizione = ?, prezzo = ? WHERE nome = ? AND via_ristorante = ? AND numero_ristorante = ? AND città_ristorante = ? ";
        boolean updated = false;

        try (Connection connection = dbManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1, pizza.getDescrizione());
            statement.setDouble(2, pizza.getPrezzo());
            statement.setString(3, pizza.getNome());
            statement.setString(4, pizza.getRistorante().getVia());
            statement.setString(5, pizza.getRistorante().getNumero());
            statement.setString(6, pizza.getRistorante().getCittà());

            int rowsAffected = statement.executeUpdate();
            if (rowsAffected > 0) {
                updated = true;
            } 

        } catch (SQLException e) {
            
            e.printStackTrace();
            throw new RuntimeException("Errore durante l'aggiornamento della pizza", e);
        }

        return updated;
    }

	
	public void deletePizza() {
		
	}
	
	
	
}
