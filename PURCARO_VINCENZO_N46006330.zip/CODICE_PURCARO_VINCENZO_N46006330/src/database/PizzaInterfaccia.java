package database;

import entity.*;

public interface PizzaInterfaccia {
	
	boolean readPizza 	 (Pizza pizza);
	void createPizza (Pizza pizza);
	boolean updatePizza (Pizza pizza);
	void deletePizza ();
	
}
