package database;

import entity.*;

public interface RistoranteInterfaccia {
	
	boolean readRistorante (Ristorante ristorante);
	void createRistorante (Ristorante ristorante);
	void updateRistorante (Ristorante ristorante);
	void deleteRistorante ();

}
