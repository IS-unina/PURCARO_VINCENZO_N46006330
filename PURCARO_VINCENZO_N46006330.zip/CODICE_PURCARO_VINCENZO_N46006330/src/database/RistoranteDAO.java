package database;

import java.sql.*;

import entity.*;

public class RistoranteDAO implements RistoranteInterfaccia {
	
	private DBManager dbManager;
	
	public RistoranteDAO(DBManager dbManager) {
        this.dbManager = dbManager;
    }
			
	public void createRistorante (Ristorante ristorante) {
		
		String query = "INSERT INTO Ristorante (nome, via, numero, CAP, città, numero_di_telefono, email ) VALUES (?, ?, ?, ?, ?,?, ?)";
		 try (PreparedStatement statement = dbManager.getConnection().prepareStatement(query)) {
			
	            statement.setString(1, ristorante.getNome());
	            statement.setString(2, ristorante.getVia());
	            statement.setString(3, ristorante.getNumero());
	            statement.setString(4, ristorante.getCAP());
	            statement.setString(5, ristorante.getCittà()); 
	            statement.setString(6, ristorante.getRecapitoTelefonico()); 
	            statement.setString(7, ristorante.getIndirizzoEmail()); 
			 
	            statement.executeUpdate();
		 		}
		 catch (SQLException e) {
	            e.printStackTrace();
	            throw new RuntimeException("Errore durante l'inserimento del ristorante", e);
	        	}	 
		 		}
	

	public boolean readRistorante (Ristorante ristorante) {		
		
		boolean esito = false;
		
		String query = "SELECT nome, via, numero, CAP, città, numero_di_telefono, email FROM Ristorante WHERE nome = ? AND via = ? AND numero = ? AND città = ?";
		try (PreparedStatement statement = dbManager.getConnection().prepareStatement(query)) {
	        
	    statement.setString(1, ristorante.getNome());
	    statement.setString(2, ristorante.getVia());
	    statement.setString(3, ristorante.getNumero());
	    statement.setString(4, ristorante.getCittà());
	    
	    try (ResultSet resultSet = statement.executeQuery()) {
	        if (resultSet.next()) {
	            
	            String CAP = resultSet.getString("CAP");
	            String telefono = resultSet.getString("numero_di_telefono");
	            String email = resultSet.getString("email");
	            
	            ristorante.SetCAP(CAP);
	            ristorante.SetRecapitoTelefonico(telefono);
	            ristorante.SetIndirizzoEmail(email);
	            esito = true;
	            } 
	        	
	    	}
			} 
		
		catch (SQLException e) {
	    e.printStackTrace();
	    throw new RuntimeException("Errore durante la ricerca del ristorante", e);
		}
		
		return esito;
		}
	
	public void updateRistorante (Ristorante ristorante) {
        String query = "UPDATE Ristorante SET numero_di_telefono = ?, email= ? WHERE nome = ? AND via = ? AND numero = ? AND città = ?";

        try (Connection connection = dbManager.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {

            statement.setString(1,ristorante.getRecapitoTelefonico() );
            statement.setString(2,ristorante.getIndirizzoEmail());
            statement.setString(3,ristorante.getNome());
            statement.setString(4,ristorante.getVia());
            statement.setString(5,ristorante.getNumero());
            statement.setString(6,ristorante.getCittà());

            int rowsAffected = statement.executeUpdate();
            
            if (rowsAffected > 0) {} 
            
            else {System.out.println("Nessun ristorante trovata da aggiornare.");}

        	} catch (SQLException e) {
        		e.printStackTrace();
        		throw new RuntimeException("Errore durante l'aggiornamento del ristorante", e);
        	}
        	}
	
	
	public void deleteRistorante () {
		
	}
	
	
}
