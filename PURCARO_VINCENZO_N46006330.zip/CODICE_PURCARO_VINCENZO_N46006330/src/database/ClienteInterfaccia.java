package database;

public interface ClienteInterfaccia {

}
