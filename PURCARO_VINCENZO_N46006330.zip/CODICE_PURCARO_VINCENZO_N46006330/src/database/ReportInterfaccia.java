package database;

public interface ReportInterfaccia {

}
