package boundary;

import entity.*;

import java.util.Scanner;

public class BoundaryCliente {
	
	private Scanner scanner;

	public BoundaryCliente () {
		this.scanner = new Scanner(System.in);
	}
	
	public Ristorante selezionaRistorante(){
		
		boolean controllo = true;
		String nome ;
		String numero;
		
		do {
			
	        System.out.print("Inserisci il nome del ristorante : ");
	        nome = scanner.nextLine();
	        
	        if (nome.matches("[a-zA-Z]+")) {controllo = false;}
	        else {System.out.println ("Il formato inserito non è corretto");}
			
		} while (controllo);
		
		controllo = true;

        System.out.print("Inserisci la via del ristorante: ");
        String via = scanner.nextLine();
        
        do {
        	
            System.out.print("Inserisci il numero civico del ristorante: ");
            numero = scanner.nextLine();
            
            if (numero.matches(".*\\d.*")) {controllo = false;}
            else {System.out.println ("Il formato inserito non è corretto");}
        	
        } while (controllo);
        
        System.out.print("Inserisci la città del ristorante: ");
        String città = scanner.nextLine();
        String CAP = new String ("...");
        String telefono = new String ("...");
        String email = new String ("...");
        
        return new Ristorante (nome,via,numero,CAP,città,telefono,email);
        
	}
	
	public Pizza selezionaPizza (Ristorante ristorante) {
		boolean controllo = true;
		String nomepizza;
		
		do {
			
			System.out.print("Inserisci il nome della pizza : ");
			nomepizza = scanner.nextLine();
			
			if (nomepizza.matches("[a-zA-Z]+")) {controllo = false;}
			else {System.out.println ("Il formato inserito non è corretto");}
			
		}while (controllo);
		
		String descrizione = new String ("...");
		float prezzo = 0;
				
		return new Pizza (nomepizza,descrizione,prezzo,ristorante.getNome(),ristorante.getVia(),ristorante.getNumero(),ristorante.getCAP(),ristorante.getCittà(),ristorante.getRecapitoTelefonico(),ristorante.getIndirizzoEmail());
	}
	
	public String confermaCliente(String domanda) {
		
		boolean condizione=true;
		String risposta = new String ();
		
		while (condizione) {
		
		System.out.print(domanda);
		risposta = scanner.nextLine();
		System.out.println("");
		
		if (risposta.equals("SI") || risposta.equals("NO") || risposta.equals("Si") || risposta.equals("No") || risposta.equals("no") || risposta.equals("si")) {
			condizione = false;
			
		}
		else {
			
			System.out.println ("La risposta inserita non è valida ");
			
		}
			
		}
		
		return risposta;
	}
	
	public int SelezionaQuantità () {
		int quantità;
		
		do {
			
		System.out.print("Specificare la quantità di pizze da ordinare : ");
		quantità = scanner.nextInt();
		
		if (quantità <= 0) {System.out.println("Quantità inserita non valida");}
		
		} while (quantità <= 0);
		
		return quantità;
	}
	
	public String InserimentoCarta () {
		
		String carta;
		boolean controllo = true;
		
		do {
		
		System.out.print("Inserire i dati della carta di credito : ");
		carta = scanner.nextLine();
		
		if (carta.length() == 16 && carta.matches("\\d*")) {controllo = false;}
		else {
			if (carta.length() != 16) 		{System.out.println("Lunghezza della carta di credito errata");}
			if (!(carta.matches("\\d*"))) 	{System.out.println("Il formato della carta di credito è errato");}
		}
		
		} while (controllo);
		
		return carta;
	}
	
	
	public void rispostaCliente(String risposta) {
		System.out.println(risposta);
	}
	
	
	
	
	

}
