package boundary;

import entity.*;

import java.util.Scanner;

public class BoundaryRistoratore {
	
    private Scanner scanner;
    private Ristoratore ristoratore;

    public BoundaryRistoratore(Ristoratore ristoratore) {
        this.scanner = new Scanner(System.in);
        this.ristoratore = new Ristoratore (ristoratore.getNome(),ristoratore.getCognome(),ristoratore.getRistorante().getNome(),
        		ristoratore.getRistorante().getVia(),ristoratore.getRistorante().getNumero(),ristoratore.getRistorante().getCAP(),
        		ristoratore.getRistorante().getCittà(),ristoratore.getRistorante().getRecapitoTelefonico(),ristoratore.getRistorante().getIndirizzoEmail());
        
    }
	
	public void aggiungiPizza (Pizza pizza) {
        System.out.print("Inserisci il nome della pizza: ");
        String nome = scanner.nextLine();

        System.out.print("Inserisci una descrizione della pizza: ");
        String descrizione = scanner.nextLine();

        System.out.print("Inserisci il prezzo della pizza: ");
        double prezzo = scanner.nextDouble();
        

        pizza.setNome(nome);
        pizza.setDescrizione(descrizione);
        pizza.setPrezzo(prezzo);
        
    }
	
	public void modificaPizza (Pizza pizza) {
		
		System.out.print("Inserisci il nome della pizza: ");
		String nome = scanner.nextLine();
		
        System.out.print("Inserisci una nuova descrizione della pizza: ");
        String descrizione = scanner.nextLine();

        System.out.print("Inserisci il nuovo prezzo della pizza: ");
        double prezzo = scanner.nextDouble();
        scanner.nextLine(); 
        
        pizza.setNome(nome);
        pizza.setDescrizione(descrizione);
        pizza.setPrezzo(prezzo);


	}
	
	public void rimuoviPizza(Pizza pizza) {
		
		System.out.print("Inserisci il nome della pizza: ");
		String nome = scanner.nextLine();
		String descrizione = "...";
		float prezzo = 0;
		
        pizza.setNome(nome);
        pizza.setDescrizione(descrizione);
        pizza.setPrezzo(prezzo);

	}
	
	public void rispostaRistoratore(String risposta) {
		System.out.println(risposta);
	}
	
	
	public Ristoratore getRistoratore () {
		return ristoratore;
	}
	
	
	
	
	
	

	
	
	

}
