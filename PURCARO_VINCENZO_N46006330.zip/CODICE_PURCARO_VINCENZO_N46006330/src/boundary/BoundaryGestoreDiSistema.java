package boundary;

public class BoundaryGestoreDiSistema {

}
