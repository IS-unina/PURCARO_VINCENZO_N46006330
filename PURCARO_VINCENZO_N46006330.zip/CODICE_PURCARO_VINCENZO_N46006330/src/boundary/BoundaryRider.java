package boundary;

public class BoundaryRider {

}
