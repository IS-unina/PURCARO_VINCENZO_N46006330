package control;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JOptionPane;

public class Checkout {

	private JFrame frame;
	private JTextField numerocarta;
	private JTextField cvv;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Checkout window = new Checkout();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Checkout() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("CHECKOUT");
		lblNewLabel.setBounds(200, 6, 91, 16);
		frame.getContentPane().add(lblNewLabel);
		
		numerocarta = new JTextField();
		numerocarta.setBounds(55, 78, 315, 26);
		frame.getContentPane().add(numerocarta);
		numerocarta.setColumns(10);
		
		JComboBox anno = new JComboBox();
		anno.setModel(new DefaultComboBoxModel(new String[] {"", "24", "25", "26", "27", "28", "29", "30", "31", "32"}));
		anno.setBounds(172, 144, 77, 27);
		frame.getContentPane().add(anno);
		
		cvv = new JTextField();
		cvv.setBounds(305, 143, 65, 26);
		frame.getContentPane().add(cvv);
		cvv.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Numero carta");
		lblNewLabel_1.setBounds(55, 58, 110, 16);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblNewLabel_2 = new JLabel("MM");
		lblNewLabel_2.setBounds(65, 116, 37, 16);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel_2_1 = new JLabel("YY");
		lblNewLabel_2_1.setBounds(174, 116, 28, 16);
		frame.getContentPane().add(lblNewLabel_2_1);
		
		JLabel lblNewLabel_2_1_1 = new JLabel("CVV");
		lblNewLabel_2_1_1.setBounds(306, 116, 28, 16);
		frame.getContentPane().add(lblNewLabel_2_1_1);
		
		
		JComboBox mese = new JComboBox();
		mese.setModel(new DefaultComboBoxModel(new String[] {"", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12"}));
		mese.setBounds(61, 144, 77, 27);
		frame.getContentPane().add(mese);
		
		JButton indietro = new JButton("INDIETRO");
		indietro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SelezionaPizza window = new SelezionaPizza();
                window.showWindow(); 
                frame.setVisible(false);
            }
        });
		indietro.setBounds(48, 213, 117, 29);
		frame.getContentPane().add(indietro);
		
		JButton paga = new JButton("PAGA");
		paga.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        String numeroCarta = numerocarta.getText();
		        String cvvCode = cvv.getText();

		        
		        if (numeroCarta.length() != 16 || !numeroCarta.matches("\\d{16}")) {
		            JOptionPane.showMessageDialog(frame, 
		                    "Il formato della carta inserito non è valido.",
		                    "Errore di validazione", 
		                    JOptionPane.ERROR_MESSAGE);
		            return; 
		        }

		       
		        if (cvvCode.length() != 3 || !cvvCode.matches("\\d{3}")) {
		            JOptionPane.showMessageDialog(frame, 
		                    "Il formato della carta inserito non è valido.",
		                    "Errore di validazione", 
		                    JOptionPane.ERROR_MESSAGE);
		            return; 
		        }
		        
		        if (mese.getSelectedIndex() == 0 || anno.getSelectedIndex() == 0) {
		            JOptionPane.showMessageDialog(frame, 
		                    "Il formato della carta inserito non è valido.",
		                    "Errore di validazione", 
		                    JOptionPane.ERROR_MESSAGE);
		        	return;
		        }

		        
		        JOptionPane.showMessageDialog(frame, 
		                "Pagamento andato a buon fine!",
		                "Ordine confermato", 
		                JOptionPane.INFORMATION_MESSAGE);
		    }
		});

		paga.setBounds(253, 213, 117, 29);
		frame.getContentPane().add(paga);
	
	}
	
    public void showWindow() {
        frame.setVisible(true);
    }
}
