package control;


import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import database.*;
import entity.Ristorante;

public class SelezionaRistorante {

    private JFrame frame;
    private final JLabel lblSelezionaRistorante = new JLabel("Seleziona Ristorante");
    private JComboBox<String> nome;
    private JComboBox<String> via;
    private JComboBox<String> civico;
    private JComboBox<String> città;

    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    SelezionaRistorante window = new SelezionaRistorante();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    /**
     * Create the application.
     */
    public SelezionaRistorante() {
        initialize();
    }

    /**
     * Initialize the contents of the frame.
     */
    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        lblSelezionaRistorante.setBounds(172, -2, 135, 29);
        frame.getContentPane().add(lblSelezionaRistorante);

        
        nome = new JComboBox<>();
        nome.setModel(new DefaultComboBoxModel<>(new String[] {"", "BellaNapoli", "Pizzeria Da Michele"}));
        nome.setBounds(28, 51, 301, 27);
        frame.getContentPane().add(nome);

        via = new JComboBox<>();
        via.setModel(new DefaultComboBoxModel<>(new String[] {"", "Via Tevere", "Via Cesare Sersale", "Via Chiaia"}));
        via.setBounds(28, 109, 228, 27);
        frame.getContentPane().add(via);

        civico = new JComboBox<>();
        civico.setModel(new DefaultComboBoxModel<>(new String[] {"", "6A", "56", "28"}));
        civico.setBounds(320, 109, 84, 27);
        frame.getContentPane().add(civico);

        città = new JComboBox<>();
        città.setModel(new DefaultComboBoxModel<>(new String[] {"", "Napoli", "Acerra"}));
        città.setBounds(28, 164, 228, 27);
        frame.getContentPane().add(città);

        JLabel labelnome = new JLabel("Nome");
        labelnome.setBounds(28, 32, 61, 16);
        frame.getContentPane().add(labelnome);

        JLabel labelvia = new JLabel("Via");
        labelvia.setBounds(28, 90, 61, 16);
        frame.getContentPane().add(labelvia);

        JLabel labelcivico = new JLabel("N. civico");
        labelcivico.setBounds(320, 90, 61, 16);
        frame.getContentPane().add(labelcivico);

        JLabel labelcittà = new JLabel("Città");
        labelcittà.setBounds(28, 148, 61, 16);
        frame.getContentPane().add(labelcittà);

        JButton avanti = new JButton("AVANTI");
        avanti.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                if (areFieldsFilled()) {
                	
                	  String nome_str = (String) nome.getSelectedItem();
                      String via_str = (String) via.getSelectedItem();
                      String civico_str = (String) civico.getSelectedItem();
                      String città_str = (String) città.getSelectedItem();
                      String cap = "...";
                      String recapito = "...";
                      String mail = "...";
                      
                      	Ristorante ristorante = new Ristorante (nome_str,via_str,civico_str,cap,città_str,recapito,mail);
                  		DBManager connessione = DBManager.getInstance();
                  		RistoranteDAO dao_rist = new RistoranteDAO (connessione);
                  		
                  		boolean esito = dao_rist.readRistorante(ristorante);
                  		
                  		if (esito == false ) {
                  			JOptionPane.showMessageDialog(frame, "Il ristorante inserito non esiste.", "Errore", JOptionPane.ERROR_MESSAGE);
                  		}
                  		else {
                  			 SelezionaPizza window = new SelezionaPizza();
                             window.showWindow();  
                             frame.setVisible(false);
                  		}

                		} else {
                    
                			JOptionPane.showMessageDialog(frame, "Per favore, completa tutti i campi.", "Errore", JOptionPane.ERROR_MESSAGE);
                		}
            }
        });
        avanti.setBounds(299, 221, 117, 29);
        frame.getContentPane().add(avanti);
    }

    private boolean areFieldsFilled() {
        return !nome.getSelectedItem().toString().isEmpty() &&
               !via.getSelectedItem().toString().isEmpty() &&
               !civico.getSelectedItem().toString().isEmpty() &&
               !città.getSelectedItem().toString().isEmpty();
    }
    public void showWindow() {
        frame.setVisible(true);
    }
}

