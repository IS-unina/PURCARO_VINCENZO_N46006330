package control;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JOptionPane;

public class SelezionaPizza {

    private JFrame frame;
    private JComboBox<String> pizza1;
    private JComboBox<String> pizza2;
    private JComboBox<String> pizza3;
    private JComboBox<String> quantitàpizza1;
    private JComboBox<String> quantitàpizza2;
    private JComboBox<String> quantitàpizza3;
    private JTextField prezzoPizza1;
    private JTextField prezzoPizza2;
    private JTextField prezzoPizza3;
    private JTextField totale;

    private final double PREZZO_MARGHERITA = 4;
    private final double PREZZO_MARINARA = 3.5;
    private final double PREZZO_TEDESCA = 6.5;

    public SelezionaPizza() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 450, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);
        
        JLabel lblNewLabel = new JLabel("Seleziona Pizze");
        lblNewLabel.setBounds(159, 6, 131, 16);
        frame.getContentPane().add(lblNewLabel);
        
        pizza1 = new JComboBox<>();
        pizza1.setModel(new DefaultComboBoxModel<>(new String[] {"", "Margherita", "Marinara", "Tedesca"}));
        pizza1.setBounds(22, 57, 144, 27);
        pizza1.addActionListener(e -> updateQuantitàState());
        frame.getContentPane().add(pizza1);
        
        pizza2 = new JComboBox<>();
        pizza2.setModel(new DefaultComboBoxModel<>(new String[] {"", "Margherita", "Marinara", "Tedesca"}));
        pizza2.setBounds(22, 112, 144, 27);
        pizza2.addActionListener(e -> updateQuantitàState());
        frame.getContentPane().add(pizza2);
        
        pizza3 = new JComboBox<>();
        pizza3.setModel(new DefaultComboBoxModel<>(new String[] {"", "Margherita", "Marinara", "Tedesca"}));
        pizza3.setBounds(22, 169, 144, 27);
        pizza3.addActionListener(e -> updateQuantitàState());
        frame.getContentPane().add(pizza3);
   
        JLabel lblNewLabel_1 = new JLabel("Pizza1");
        lblNewLabel_1.setBounds(22, 37, 61, 16);
        frame.getContentPane().add(lblNewLabel_1);
        
        JLabel lblNewLabel_2 = new JLabel("Pizza2 (opzionale)");
        lblNewLabel_2.setBounds(22, 96, 131, 16);
        frame.getContentPane().add(lblNewLabel_2);
        
        JLabel lblNewLabel_3 = new JLabel("Pizza3 (opzionale)");
        lblNewLabel_3.setBounds(22, 151, 131, 16);
        frame.getContentPane().add(lblNewLabel_3);
        
        JButton checkout = new JButton("CHECKOUT");
        checkout.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	if (pizza1.getSelectedIndex() == 0 || quantitàpizza1.getSelectedIndex() == 0) {
                    JOptionPane.showMessageDialog(frame, 
                            "Seleziona una pizza e una quantità per Pizza1 prima di procedere.", 
                            "Errore di selezione", 
                            JOptionPane.ERROR_MESSAGE);
                } else {
                    Checkout window = new Checkout();
                    window.showWindow(); 
                    frame.setVisible(false);
                }
            }
            
        });
        checkout.setBounds(310, 280, 117, 29);
        frame.getContentPane().add(checkout);
        
        JButton indietro = new JButton("INDIETRO");
        indietro.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                SelezionaRistorante window = new SelezionaRistorante();
                window.showWindow(); 
                frame.setVisible(false);
            }
        });
        indietro.setBounds(32, 280, 117, 29);
        frame.getContentPane().add(indietro);
        
        quantitàpizza1 = new JComboBox<>();
        quantitàpizza1.setModel(new DefaultComboBoxModel<>(new String[] {"0", "1", "2", "3", "4", "5"}));
        quantitàpizza1.setBounds(201, 57, 70, 27);
        quantitàpizza1.setEnabled(false);
        quantitàpizza1.addActionListener(e -> updatePrice());
        frame.getContentPane().add(quantitàpizza1);
        
        quantitàpizza2 = new JComboBox<>();
        quantitàpizza2.setModel(new DefaultComboBoxModel<>(new String[] {"0", "1", "2", "3", "4", "5"}));
        quantitàpizza2.setBounds(201, 112, 70, 27);
        quantitàpizza2.setEnabled(false);
        quantitàpizza2.addActionListener(e -> updatePrice());
        frame.getContentPane().add(quantitàpizza2);
        
        quantitàpizza3 = new JComboBox<>();
        quantitàpizza3.setModel(new DefaultComboBoxModel<>(new String[] {"0", "1", "2", "3", "4", "5"}));
        quantitàpizza3.setBounds(201, 169, 70, 27);
        quantitàpizza3.setEnabled(false);
        quantitàpizza3.addActionListener(e -> updatePrice());
        frame.getContentPane().add(quantitàpizza3);
        
        prezzoPizza1 = new JTextField();
        prezzoPizza1.setBounds(281, 57, 70, 27);
        prezzoPizza1.setEditable(false);
        frame.getContentPane().add(prezzoPizza1);
        
        prezzoPizza2 = new JTextField();
        prezzoPizza2.setBounds(281, 112, 70, 27);
        prezzoPizza2.setEditable(false);
        frame.getContentPane().add(prezzoPizza2);
        
        prezzoPizza3 = new JTextField();
        prezzoPizza3.setBounds(281, 169, 70, 27);
        prezzoPizza3.setEditable(false);
        frame.getContentPane().add(prezzoPizza3);
        
        JLabel lblTotale = new JLabel("TOTALE :");
        lblTotale.setBounds(184, 223, 61, 16);
        frame.getContentPane().add(lblTotale);

        totale = new JTextField();
        totale.setText("NULL");
        totale.setBounds(281, 218, 70, 27);
        totale.setEditable(false);
        frame.getContentPane().add(totale);

        updateQuantitàState();
        updatePrice();
    }

    private void updateQuantitàState() {
        quantitàpizza1.setEnabled(pizza1.getSelectedIndex() > 0);
        quantitàpizza2.setEnabled(pizza2.getSelectedIndex() > 0);
        quantitàpizza3.setEnabled(pizza3.getSelectedIndex() > 0);
        updatePrice();
    }

    private void updatePrice() {
        double price1 = getPrice(pizza1, quantitàpizza1);
        double price2 = getPrice(pizza2, quantitàpizza2);
        double price3 = getPrice(pizza3, quantitàpizza3);

        prezzoPizza1.setText(String.format("%.2f", price1));
        prezzoPizza2.setText(String.format("%.2f", price2));
        prezzoPizza3.setText(String.format("%.2f", price3));

        double total = price1 + price2 + price3;
        totale.setText(String.format("%.2f", total));
    }

    private double getPrice(JComboBox<String> pizzaBox, JComboBox<String> quantityBox) {
        String pizza = (String) pizzaBox.getSelectedItem();
        int quantity = Integer.parseInt((String) quantityBox.getSelectedItem());
        double price = 0;

        if (pizza != null && !pizza.isEmpty()) {
            switch (pizza) {
                case "Margherita":
                    price = PREZZO_MARGHERITA;
                    break;
                case "Marinara":
                    price = PREZZO_MARINARA;
                    break;
                case "Tedesca":
                    price = PREZZO_TEDESCA;
                    break;
            }
        }

        return price * quantity;
    }

    public void showWindow() {
        frame.setVisible(true);
    }
}
