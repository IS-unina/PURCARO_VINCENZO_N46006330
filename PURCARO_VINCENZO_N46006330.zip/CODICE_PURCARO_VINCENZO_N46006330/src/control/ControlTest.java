package control;

import static org.junit.Assert.*;

import org.junit.Test;

import boundary.BoundaryCliente;
import database.DBManager;
import database.RistoranteDAO;
import database.PizzaDAO;
import entity.Cliente;
import entity.Pizza;
import entity.Ristorante;
import java.util.*;

public class ControlTest {

	@Test
	public void testEffettuaOrdine1() {
		
		DBManager connessione = DBManager.getInstance();
		Control PizzaaCasa = Control.getInstance(connessione);
		
		int ext_id = PizzaaCasa.getIdOrdine() + 1;
		
		BoundaryCliente interfaccia2 = new BoundaryCliente ();
		PizzaaCasa.effettuaOrdine(interfaccia2);
		
		int id = PizzaaCasa.getIdOrdine();
		
		System.out.println("");
		
		assert ext_id == id;
		
		
	}
	
	@Test
	public void testEffettuaOrdine2() {
		
		BoundaryCliente interfaccia2 = new BoundaryCliente ();
		Ristorante ristorante1 = new Ristorante ("BellaNapoli","Via Tevere","6A","80011","Acerra","tony@gmail.com","3338904567");
		
		Pizza pizza = interfaccia2.selezionaPizza(ristorante1);
		
		System.out.println("");
		
		assert pizza.getNome().matches("[a-zA-Z]+");
		
	}
	
	@Test
	public void testEffettuaOrdine3() {
		
		BoundaryCliente interfaccia2 = new BoundaryCliente ();
		Ristorante ristorante = interfaccia2.selezionaRistorante();
		
		System.out.println("");
		
		assert ristorante.getNumero().matches(".*\\d.*");

	}
	
	@Test
	public void testEffettuaOrdine4() {
		
		BoundaryCliente interfaccia2 = new BoundaryCliente ();
		Ristorante ristorante = interfaccia2.selezionaRistorante();
		
		System.out.println("");
		
		assert ristorante.getNome().matches("[a-zA-Z]+");
		
	}
	
	@Test
	public void testEffettuaOrdine5() {
		
		BoundaryCliente interfaccia2 = new BoundaryCliente ();
		int quantità = interfaccia2.SelezionaQuantità();
		
		System.out.println("");
		
		assert quantità > 0;

		
	}
	 
	@Test
	public void testEffettuaOrdine6() {
		
		BoundaryCliente interfaccia2 = new BoundaryCliente ();
		String carta = interfaccia2.InserimentoCarta();
		
		System.out.println("");
		
		assert carta.length() == 16;

	}
	
	@Test
	public void testEffettuaOrdine7() {
		
		
		BoundaryCliente interfaccia2 = new BoundaryCliente ();
		String carta = interfaccia2.InserimentoCarta();
		
		System.out.println("");
		
		assert carta.matches("\\d*");
		
	}
	
	

	
	@Test
	public void testunitàEffettuaOrdine1() {
		
		
		DBManager connessione = DBManager.getInstance();
		Control PizzaaCasa = Control.getInstance(connessione);
		
		RistoranteDAO connessioneRistorante = new RistoranteDAO(connessione);
		BoundaryCliente cliente = new BoundaryCliente ();
		
		// 0)
		boolean esito;
		String risposta = new String();
		Ristorante ristorante = new Ristorante();
		ristorante = cliente.selezionaRistorante();
		esito = connessioneRistorante.readRistorante(ristorante);
		double tot= 0;
		
		// 1)
		if (esito == true) {}
		
		// 2)
		else {
		risposta = new String ("Il ristorante selezionato non esiste");
		cliente.rispostaCliente(risposta);

		}
		
		assert risposta.matches("Il ristorante selezionato non esiste");
		
	}
	
	@Test
	public void testunitàEffettuaOrdine2() {
		
		DBManager connessione = DBManager.getInstance();
		Control PizzaaCasa = Control.getInstance(connessione);
		
		RistoranteDAO connessioneRistorante = new RistoranteDAO(connessione);
		PizzaDAO connessionePizza = new PizzaDAO (connessione);
		
		BoundaryCliente cliente = new BoundaryCliente ();
		
		int id_ordine = 123539;
		int ext_id = id_ordine + 1;
		int retro = 0;
		
		// 0)
		boolean esito;
		String risposta;
		Ristorante ristorante = new Ristorante();
		ristorante = cliente.selezionaRistorante();
		esito = connessioneRistorante.readRistorante(ristorante);
		double tot= 0;
		
		// 1)
		if (esito == true) {
		risposta = new String ("Ristorante selezionato con successo");
		List <Pizza> carrello = new ArrayList<>();
		cliente.rispostaCliente(risposta);
		Pizza pizza = new Pizza (ristorante);
		boolean esitopizza;
		boolean condizione = true;

		// 3)
		do {
			pizza = cliente.selezionaPizza(ristorante);
			esitopizza = connessionePizza.readPizza(pizza);
			
		// 4)
		if (esitopizza == true ) {
		int qta = cliente.SelezionaQuantità();
			
		// 6)
		for (int i=0;i<qta;i++) {
		carrello.add(pizza);
		tot += pizza.getPrezzo();
		}
			
		}
			
		// 5)
		else {}
		
		// 7)
		risposta = "Desidera inserire una nuova pizza ? [SI | NO ] : ";
		risposta = cliente.confermaCliente(risposta);
		
		// 8)
		if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {retro ++;}
		
		// 9)
		else {
		condizione = false;
		}
		
		// 10)
		} while (condizione);
		
		// 11)
		if (tot != 0) {	
		risposta = "TOTALE : " + tot + " . Desidera confermare l'ordine ? [SI | NO ] : " ;
		risposta = cliente.confermaCliente(risposta);
		
		// 13)
		if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {	
		String carta = cliente.InserimentoCarta();		
		id_ordine += 1; 
		risposta = "PAGAMENTO ANDATO A BUON FINE ! ID ORDINE : " + id_ordine;
		cliente.rispostaCliente(risposta);						
		}
		
		// 14)
		else {}
		
		}
			
		// 12)
		else {}	
		
		}
		
		// 2)
		else {}
		
		assert ext_id == id_ordine && retro == 0;
			
		}
	
		@Test
		public void testunitàEffettuaOrdine3() {
			
			
			DBManager connessione = DBManager.getInstance();
			Control PizzaaCasa = Control.getInstance(connessione);
			
			RistoranteDAO connessioneRistorante = new RistoranteDAO(connessione);
			PizzaDAO connessionePizza = new PizzaDAO (connessione);
			
			BoundaryCliente cliente = new BoundaryCliente ();
			
			int id_ordine = 123539;
			int ext_id = id_ordine;
			int retro = 0;
			
			// 0)
			boolean esito;
			String risposta;
			Ristorante ristorante = new Ristorante();
			ristorante = cliente.selezionaRistorante();
			esito = connessioneRistorante.readRistorante(ristorante);
			double tot= 0;
			
			// 1)
			if (esito == true) {
			risposta = new String ("Ristorante selezionato con successo");
			List <Pizza> carrello = new ArrayList<>();
			cliente.rispostaCliente(risposta);
			Pizza pizza = new Pizza (ristorante);
			boolean esitopizza;
			boolean condizione = true;

			// 3)
			do {
				pizza = cliente.selezionaPizza(ristorante);
				esitopizza = connessionePizza.readPizza(pizza);
				
			// 4)
			if (esitopizza == true ) {
			int qta = cliente.SelezionaQuantità();
				
			// 6)
			for (int i=0;i<qta;i++) {
			carrello.add(pizza);
			tot += pizza.getPrezzo();
			}
				
			}
				
			// 5)
			else {}
			
			// 7)
			risposta = "Desidera inserire una nuova pizza ? [SI | NO ] : ";
			risposta = cliente.confermaCliente(risposta);
			
			// 8)
			if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {retro ++;}
			
			// 9)
			else {
			condizione = false;
			}
			
			// 10)
			} while (condizione);
			
			// 11)
			if (tot != 0) {	
			risposta = "TOTALE : " + tot + " . Desidera confermare l'ordine ? [SI | NO ] : " ;
			risposta = cliente.confermaCliente(risposta);
			
			// 13)
			if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {id_ordine += 1;}
			
			// 14)
			else {
			risposta = "Ordine annullato con successo";
			carrello = null;
			cliente.rispostaCliente(risposta);
			}
			}
				
			// 12)
			else {}	
			
			}
			
			// 2)
			else {}
			
			assert ext_id == id_ordine && retro == 0;
		
			}
		
			
		@Test
		public void testunitàEffettuaOrdine4() {
			
			DBManager connessione = DBManager.getInstance();
			Control PizzaaCasa = Control.getInstance(connessione);
			
			RistoranteDAO connessioneRistorante = new RistoranteDAO(connessione);
			PizzaDAO connessionePizza = new PizzaDAO (connessione);
			
			BoundaryCliente cliente = new BoundaryCliente ();
			
			int id_ordine = 123539;
			int retro = 0;
			
			// 0)
			boolean esito;
			String risposta = new String();
			Ristorante ristorante = new Ristorante();
			ristorante = cliente.selezionaRistorante();
			esito = connessioneRistorante.readRistorante(ristorante);
			double tot= 0;
			
			// 1)
			if (esito == true) {
			risposta = new String ("Ristorante selezionato con successo");
			List <Pizza> carrello = new ArrayList<>();
			cliente.rispostaCliente(risposta);
			Pizza pizza = new Pizza (ristorante);
			boolean esitopizza;
			boolean condizione = true;

			// 3)
			do {
				pizza = cliente.selezionaPizza(ristorante);
				esitopizza = connessionePizza.readPizza(pizza);
				
			// 4)
			if (esitopizza == true ) {
			int qta = cliente.SelezionaQuantità();
				
			// 6)
			for (int i=0;i<qta;i++) {
			carrello.add(pizza);
			tot += pizza.getPrezzo();
			}
				
			}
				
			// 5)
			else {
				risposta = "La pizza selezionata non esiste";
				cliente.rispostaCliente(risposta);	
			}
			
			// 7)
			risposta = "Desidera inserire una nuova pizza ? [SI | NO ] : ";
			risposta = cliente.confermaCliente(risposta);
			
			// 8)
			if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {retro ++;}
			
			// 9)
			else {
			condizione = false;
			}
			
			// 10)
			} while (condizione);
			
			// 11)
			if (tot != 0) {
			
			// 13)
			if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {}
			
			// 14)
			else {}
			
			}
				
			// 12)
			else {
			risposta = "Ordine annullato, non sono presenti pizze nell'ordine";
			cliente.rispostaCliente(risposta);
			}	
			}
			
			// 2)
			else {}
			
			
			assert retro == 0 && risposta.matches("Ordine annullato, non sono presenti pizze nell'ordine");
			
			}
		
			@Test
			public void testunitàEffettuaOrdine5() {
				
				
				DBManager connessione = DBManager.getInstance();
				Control PizzaaCasa = Control.getInstance(connessione);
				
				RistoranteDAO connessioneRistorante = new RistoranteDAO(connessione);
				PizzaDAO connessionePizza = new PizzaDAO (connessione);
				
				BoundaryCliente cliente = new BoundaryCliente ();
				
				int id_ordine = 123539;
				int retro = 0;
				
				// 0)
				boolean esito;
				String risposta = new String();
				Ristorante ristorante = new Ristorante();
				ristorante = cliente.selezionaRistorante();
				esito = connessioneRistorante.readRistorante(ristorante);
				double tot= 0;
				
				// 1)
				if (esito == true) {
				risposta = new String ("Ristorante selezionato con successo");
				List <Pizza> carrello = new ArrayList<>();
				cliente.rispostaCliente(risposta);
				Pizza pizza = new Pizza (ristorante);
				boolean esitopizza;
				boolean condizione;

				// 3)
				do {
					pizza = cliente.selezionaPizza(ristorante);
					esitopizza = connessionePizza.readPizza(pizza);
					
				// 4)
				if (esitopizza == true ) {
				int qta = cliente.SelezionaQuantità();
					
				// 6)
				for (int i=0;i<qta;i++) {
				carrello.add(pizza);
				tot += pizza.getPrezzo();
				}
					
				}
					
				// 5)
				else {
					risposta = "La pizza selezionata non esiste";
					cliente.rispostaCliente(risposta);	
				}
				
				// 7)
				risposta = "Desidera inserire una nuova pizza ? [SI | NO ] : ";
				risposta = cliente.confermaCliente(risposta);
				
				// 8)
				if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {
					condizione = true;
					retro ++;}
				
				// 9)
				else {
				condizione = false;
				}
				
				// 10)
				} while (condizione);
				
				// 11)
				if (tot != 0) {
				
				// 13)
				if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {}
				
				// 14)
				else {}
				
				}
					
				// 12)
				else {
				risposta = "Ordine annullato, non sono presenti pizze nell'ordine";
				cliente.rispostaCliente(risposta);
				}	
				}
				
				// 2)
				else {}
				
				assert retro == 1 && risposta.matches("Ordine annullato, non sono presenti pizze nell'ordine");
				
			}
	
		
			}
