package control;

import entity.*; 

import boundary.*;

import database.*;

import java.util.*;


public class Control {

	private static Control instance = null;	
	private static int id_ordine;
	
	private PizzaDAO connessionePizza;
	private RistoranteDAO connessioneRistorante;
	
    private Control(DBManager dbManager) {
        connessionePizza = new PizzaDAO(dbManager);
        connessioneRistorante = new RistoranteDAO(dbManager);
        id_ordine = 123539;
         
    }
	
	public static Control getInstance(DBManager dbManager){
		
	if (instance == null) {instance = new Control(dbManager);}
	
	return instance; }
	
	public int getIdOrdine() {
		return id_ordine;
	}
	
	
	//AGGIUNGI PIZZA
	
	public void aggiungiPizza(BoundaryRistoratore ristoratore){
		
		Pizza pizza = new Pizza (ristoratore.getRistoratore().getRistorante());
		ristoratore.aggiungiPizza(pizza);
		connessionePizza.createPizza(pizza); 
		
	}
	
	
	//MODIFICA PIZZA
	
	public void modificaPizza (BoundaryRistoratore ristoratore) {
		
		boolean esito;
		String risposta;
		
		Pizza pizza = new Pizza (ristoratore.getRistoratore().getRistorante());
		ristoratore.modificaPizza(pizza);
		esito = connessionePizza.updatePizza(pizza);
		
		if (esito == true) {risposta = new String ("Pizza modificata con successo");}
		
		else {risposta = new String ("La pizza selezionata non esiste");}
		
		ristoratore.rispostaRistoratore(risposta);
			
		}
	
	
	
	
	public void rimuoviPizza (BoundaryRistoratore ristoratore) {
	
	 Pizza pizza = new Pizza (ristoratore.getRistoratore().getRistorante());	
	 ristoratore.rimuoviPizza(pizza);
	 
	 //...
		
		
	}
	
	public void effettuaOrdine(BoundaryCliente cliente) {
		
		boolean esito;
		String risposta;
		
		Ristorante ristorante = new Ristorante();
		ristorante = cliente.selezionaRistorante();
		esito = connessioneRistorante.readRistorante(ristorante);
		double tot= 0;
		
		if (esito == true) {
		risposta = new String ("Ristorante selezionato con successo");

		List <Pizza> carrello = new ArrayList<>();
		
		cliente.rispostaCliente(risposta);
		Pizza pizza = new Pizza (ristorante);
		boolean esitopizza;
		boolean condizione;
		
		
		do {
		
		pizza = cliente.selezionaPizza(ristorante);
		esitopizza = connessionePizza.readPizza(pizza);
		
		
		if (esitopizza == true ) {
			
			int qta = cliente.SelezionaQuantità();
			
			for (int i=0;i<qta;i++) {
				
				carrello.add(pizza);
				tot += pizza.getPrezzo();
				
			}
		
		}
		
		else {
			
			risposta = "La pizza selezionata non esiste";
			cliente.rispostaCliente(risposta);
			
		}
		
		risposta = "Desidera inserire una nuova pizza ? [SI | NO ] : ";
		risposta = cliente.confermaCliente(risposta);
		
		if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {
		condizione = true;
		}
		else {
		condizione = false;
		}
		
		
		} while (condizione);
		
		if (tot != 0) {
			
			risposta = "TOTALE : " + tot + " . Desidera confermare l'ordine ? [SI | NO ] : " ;
			risposta = cliente.confermaCliente(risposta);
			
				if (risposta.equals("SI") ||risposta.equals("si") ||risposta.equals("Si") ) {
				
					String carta = cliente.InserimentoCarta();
					
					id_ordine += 1; 
					
					risposta = "PAGAMENTO ANDATO A BUON FINE ! ID ORDINE : " + id_ordine;
					cliente.rispostaCliente(risposta);
				
																				}
				else {
					
					risposta = "Ordine annullato con successo";
					carrello = null;
					cliente.rispostaCliente(risposta);
					}
			}
			else {
					risposta = "Ordine annullato, non sono presenti pizze nell'ordine";
					cliente.rispostaCliente(risposta);
				}
				
			}
		
		else {
			
		risposta = new String ("Il ristorante selezionato non esiste");
		cliente.rispostaCliente(risposta);
		
		}
			
		}
		
	
	public void registrazioneRistoratore() {
		 //...
	}
	
	public void registrazioneCliente() {
		 //...
	}
	
	public void aggiungiRider () {
		 //...
	}
	
	public void consultaReport () {
		 //...
	}
	
    public void chiudiConnessioneDB() {
        DBManager.getInstance().closeConnection();
    }
	
	
	}


	

