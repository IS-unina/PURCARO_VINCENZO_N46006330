import java.lang.*;

module Pizza_a_casa {
	requires java.desktop;
	
	requires java.sql;
	 requires junit;
	 
	 
	
}