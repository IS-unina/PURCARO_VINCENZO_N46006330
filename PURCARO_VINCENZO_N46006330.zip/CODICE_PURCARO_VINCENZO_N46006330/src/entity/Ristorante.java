package entity;


public class Ristorante {
	private String nome;
	private String via;
	private String numero;
	private String CAP;
	private String città;
	private String recapitoTelefonico;
	private String indirizzoEmail;
	
	public Ristorante (String nome , String via , String numero , String CAP , String città , String recapitoTelefonico , String indirizzoEmail ) {
		
	this.nome = new String 	(nome);
	this.via = new String (via);
	this.numero = new String (numero);
	this.CAP = new String (CAP);
	this.città = new String (città);
	this.recapitoTelefonico = new String (recapitoTelefonico);
	this.indirizzoEmail = new String (indirizzoEmail);	
	}
	
	public Ristorante () {
		
	}
	
	
	public String getNome() {
		return nome;
	}
	
	public String getVia() {
		return via;	
	}
	
	public String getNumero() {
		return numero;
	}
	
	public String getCAP() {
		return CAP;
	}
	
	public String getCittà(){
		return città;
	}
	
	public String getRecapitoTelefonico() {
		return recapitoTelefonico;
	}
	
	public String getIndirizzoEmail() {
		return indirizzoEmail;
	}
	
	public void SetNome(String nome) {
		this.nome = nome;
	}
	
	public void SetVia(String via) {
		this.via=via;
	}
	
	public void SetNumero(String numero) {
		this.numero=numero;
	}
	
	public void SetCAP(String CAP) {
		this.CAP=CAP;
	}
	
	public void SetCittà(String città) {
		this.città=città;
	}
	
	public void SetRecapitoTelefonico(String telefono) {
		this.recapitoTelefonico=telefono;
	}
	
	public void SetIndirizzoEmail(String mail) {
		this.indirizzoEmail=mail;
	}
}
