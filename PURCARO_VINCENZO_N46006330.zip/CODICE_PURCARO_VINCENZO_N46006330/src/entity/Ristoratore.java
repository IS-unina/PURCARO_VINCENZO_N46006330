package entity;



public class Ristoratore {
	
	private String nome;
	private String cognome;
	private Ristorante ristorante;
	
	
	public Ristoratore (String nome, String cognome, String nomerist , String via , String numero, String CAP, String città , String tel , String mail) {
		
	this.nome = new String (nome);
	this.cognome = new String (cognome);
	this.ristorante = new Ristorante ();
	ristorante.SetNome(nomerist);
	ristorante.SetVia(via);
	ristorante.SetNumero(numero);
	ristorante.SetCAP(CAP);
	ristorante.SetCittà(città);
	ristorante.SetRecapitoTelefonico(tel);
	ristorante.SetIndirizzoEmail(mail);
	
		
}
	
	public String getNome () {
		return nome;
	}
	
	public String getCognome () {
		return cognome;
	}
	
	public Ristorante getRistorante() {
		return ristorante;
	}
	
}
