package entity;

public class NotificaRitiro {

}
