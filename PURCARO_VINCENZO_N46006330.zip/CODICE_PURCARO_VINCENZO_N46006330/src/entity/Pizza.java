package entity;

public class Pizza {
	
	private String nome;
	private String descrizione;
	private double prezzo;
	private Ristorante ristorante;
	
	public Pizza (String nome, String descrizione , double prezzo, String nomerist , String via , String numero, String CAP, String città , String tel , String mail) {
		
		this.nome = new String (nome);
		this.descrizione = new String (descrizione);
		this.prezzo = prezzo;
		this.ristorante = new Ristorante ();
		ristorante.SetNome(nomerist);
		ristorante.SetVia(via);
		ristorante.SetNumero(numero);
		ristorante.SetCAP(CAP);
		ristorante.SetCittà(città);
		ristorante.SetRecapitoTelefonico(tel);
		ristorante.SetIndirizzoEmail(mail);
		
	}
	
	public Pizza (Ristorante ristorante) {
		
	this.ristorante = new Ristorante (ristorante.getNome(),ristorante.getVia(),ristorante.getNumero(),ristorante.getCAP(),ristorante.getCittà(),ristorante.getRecapitoTelefonico(),ristorante.getIndirizzoEmail());
		
	}
	
	public Pizza () {
		
	}
	
	public void setDescrizione (String descrizione) {
		this.descrizione = descrizione;
	}
	
	public void setNome (String nome) {
		this.nome = nome;
	}
	
	public void setPrezzo (double prezzo) {
		this.prezzo = prezzo;
	}
	
	public String getDescrizione() {
		return descrizione;
	}
	
	public String getNome() {
		return nome;
	}
	
	public double getPrezzo() {
		return prezzo;
	}
	
	public Ristorante getRistorante() {
		return ristorante;
	}

}
