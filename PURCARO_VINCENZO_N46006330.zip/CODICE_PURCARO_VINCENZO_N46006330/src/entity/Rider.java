package entity;

public class Rider {

	
	
	
}
