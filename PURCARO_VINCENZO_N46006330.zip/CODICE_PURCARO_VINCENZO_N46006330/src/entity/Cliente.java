package entity;

public class Cliente {
	
	private String nome;
	private String cognome;
	private String recapitoTelefonico;
	private String CartaDiCredito;
	
	public Cliente (String nome, String cognome, String recapitoTelefonico, String CartaDiCredito ) {
		
		this.nome = new String (nome);
		this.cognome = new String (cognome);
		this.recapitoTelefonico = new String (recapitoTelefonico);
		this.CartaDiCredito = new String (CartaDiCredito);
		
	}
	
	
	

}
