package entity;

public class NotificaConsegna {

}
