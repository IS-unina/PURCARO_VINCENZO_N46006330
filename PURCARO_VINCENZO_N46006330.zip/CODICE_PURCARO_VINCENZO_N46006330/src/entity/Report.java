package entity;

public class Report {

}
